"""
   # CTI-110
   # P3HW2 - Salary
   # Your Name
   # Date
"""

#prompting a user for input
employeeName = input ('Enter your name: ')
payRate = (float (input ('Enter your payment rate $')))
workingHours = (float (input ('How many hours did you work this week? ')))
#Overtime
if workingHours <= 40:
    regularHours = workingHours
    overtimeHours = 0
    overtimeEarning = 0
#grosspay
    regularEarnings = round (workingHours * payRate, 2)
    grossPay = regularEarnings
else:
    regularHours = 40
#calculating the amount of time worked overtime
    overtimeHours = round (workingHours - 40.00, 2)
#payment calculation
    regularEarnings = round (regularHours * payRate, 2)
#overtime earning calculation
    overtimeEarning = round (overtimeHours * 1.5,  2)
#calculating grossPay
    grossPay = round (regularEarnings + overtimeEarning, 2)

#Output
print ("Employee Name: ", employeeName)
print ("Employee Pay Rate: ", payRate)
print ("The hours the employee worked is: ", workingHours)
print ("Employee overtime: ", overtimeHours)
print ("Employee Overtime Payment: ", overtimeEarning)
print ("Employee payment for regular hours: ", regularEarnings)
print ("Employee overall salary: ", grossPay)
